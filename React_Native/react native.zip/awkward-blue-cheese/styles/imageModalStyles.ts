import { Dimensions, Platform } from 'react-native';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');
const isIOS = Platform.OS === 'ios';
const isAndroid = Platform.OS === 'android';

export const imageModalStyles = {
  // Main modal container
  fullImageModal: {
    flex: 1,
    backgroundColor: '#000',
  },
  
  // Header section
  fullImageHeader: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: 'rgba(0, 0, 0, 0.95)',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
    paddingTop: isIOS ? 12 : isAndroid ? 20 : 12,
  },
  
  closeFullImageButton: {
    padding: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 20,
    width: 40,
    height: 40,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
  
  fullImageTitle: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600' as const,
    flex: 1,
    textAlign: 'center' as const,
    marginHorizontal: 8,
  },
  
  fullImageHeaderSpacer: {
    width: 40,
  },
  
  // Loading states for WebView
  loadingAnimation: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    padding: 40,
  },
  
  loadingText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600' as const,
    marginTop: 20,
    textAlign: 'center' as const,
  },
  
  loadingSubtext: {
    color: '#94a3b8',
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center' as const,
  },
  
  // Error state
  errorContainer: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    padding: 30,
  },
  
  errorIcon: {
    marginBottom: 16,
  },
  
  errorTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600' as const,
    marginBottom: 8,
    textAlign: 'center' as const,
  },
  
  errorMessage: {
    color: '#94a3b8',
    fontSize: 14,
    textAlign: 'center' as const,
    marginBottom: 24,
    lineHeight: 20,
  },
  
  retryButton: {
    backgroundColor: '#8b5cf6',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 25,
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 8,
  },
  
  retryButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600' as const,
  },
  
  // Old image container (for reference/fallback)
  fullImageContainer: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
    padding: 20,
  },
  
  fullImageView: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain' as const,
  },
  
  // No image/fallback container
  noFullImageContainer: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    padding: 30,
  },
  
  noFullImageText: {
    color: '#6b7280',
    fontSize: 16,
    marginTop: 16,
    textAlign: 'center' as const,
  },
  
  // Instructions overlay
  instructionsOverlay: {
    position: 'absolute' as const,
    bottom: 20,
    left: 20,
    right: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.3)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  
  instructionsTitle: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600' as const,
    marginBottom: 12,
    textAlign: 'center' as const,
  },
  
  instructionsList: {
    gap: 10,
    marginBottom: 16,
  },
  
  instructionItem: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 10,
  },
  
  instructionIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
  
  instructionText: {
    color: '#e5e7eb',
    fontSize: 14,
    flex: 1,
  },
  
  gotItButton: {
    backgroundColor: '#8b5cf6',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 25,
    alignItems: 'center' as const,
  },
  
  gotItButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600' as const,
  },
  
  // Simple instructions (minimal)
  simpleInstructions: {
    position: 'absolute' as const,
    bottom: 20,
    left: 0,
    right: 0,
    alignItems: 'center' as const,
  },
  
  simpleInstructionsText: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 13,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    textAlign: 'center' as const,
  },
  
  // Progress indicator for loading
  progressContainer: {
    position: 'absolute' as const,
    top: 0,
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  
  progressBar: {
    height: '100%',
    backgroundColor: '#8b5cf6',
  },
  
  // Close button overlay for WebView
  webViewCloseOverlay: {
    position: 'absolute' as const,
    top: 0,
    left: 0,
    right: 0,
    height: 60,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 1000,
  },
  
  // Zoom controls (if needed for fallback)
  zoomControls: {
    position: 'absolute' as const,
    bottom: 30,
    left: 20,
    right: 20,
    flexDirection: 'row' as const,
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
    gap: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    borderRadius: 30,
    paddingVertical: 12,
    paddingHorizontal: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  
  zoomButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(139, 92, 246, 0.9)',
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
  
  zoomButtonDisabled: {
    backgroundColor: 'rgba(100, 100, 100, 0.5)',
  },
  
  zoomIndicator: {
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    paddingHorizontal: 20,
    minWidth: 100,
  },
  
  zoomText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600' as const,
  },
  
  zoomLevelText: {
    color: '#94a3b8',
    fontSize: 12,
    marginTop: 2,
  },
  
  // Action controls
  actionControls: {
    position: 'absolute' as const,
    top: 80,
    right: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    borderRadius: 20,
    padding: 8,
    flexDirection: 'row' as const,
    gap: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  
  actionButton: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 15,
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
  },
  
  actionButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600' as const,
  },
  
  actionButtonTextDisabled: {
    color: '#6b7280',
  },
  
  // Pan helper text
  panHelper: {
    position: 'absolute' as const,
    bottom: 20,
    left: 0,
    right: 0,
    alignItems: 'center' as const,
  },
  
  panHelperText: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 13,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    textAlign: 'center' as const,
  },
  
  // Status bar spacer for Android
  statusBarSpacer: {
    height: isAndroid ? 24 : 0,
    backgroundColor: '#000',
  },
  
  // Bottom safe area for gestures
  bottomSafeArea: {
    height: isIOS ? 34 : 0,
    backgroundColor: 'transparent',
  },
};