// styles/chatStyles.ts - Updated Version
import { StyleSheet } from 'react-native';

export const chatStyles = StyleSheet.create({
  // Container
  container: {
    flex: 1,
    backgroundColor: '#111827',
  },
  
  // Chat Container
  chatContainer: {
    flex: 1,
    backgroundColor: '#111827',
  },
  chatContent: {
    paddingHorizontal: 16,
    paddingVertical: 20,
  },
  
  // Message Row
  messageRow: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-start',
  },
  userRow: {
    justifyContent: 'flex-end',
  },
  assistantRow: {
    justifyContent: 'flex-start',
  },
  
  // Avatars
  assistantAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
    marginTop: 4,
  },
  userAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#8b5cf6',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
    marginTop: 4,
  },
  
  // Message Bubble
  messageBubble: {
    maxWidth: '82%',
    padding: 12,
    borderRadius: 18,
  },
  userBubble: {
    backgroundColor: '#8b5cf6',
    borderTopRightRadius: 4,
  },
  assistantBubble: {
    backgroundColor: '#1f2937',
    borderTopLeftRadius: 4,
    borderWidth: 1,
    borderColor: '#374151',
  },
  analysisBubble: {
    backgroundColor: 'transparent',
    borderWidth: 0,
    padding: 0,
    maxWidth: '100%',
  },
  
  // User Image
  userImageContainer: {
    width: 180,
    height: 120,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
    borderWidth: 2,
    borderColor: 'rgba(139, 92, 246, 0.4)',
  },
  userImage: {
    width: '100%',
    height: '100%',
    backgroundColor: '#4b5563',
  },
  imageBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(139, 92, 246, 0.9)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  imageBadgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '600',
  },
  
  // Analysis Preview Container
  analysisPreviewContainer: {
    width: 280,
    marginBottom: 12,
  },
  
  // Analysis Preview
  analysisPreview: {
    backgroundColor: '#fff',
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#8b5cf6',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
    height: 160,
  },
  
  analysisPreviewImage: {
    width: '100%',
    height: '100%',
    backgroundColor: '#f8fafc',
  },
  
  analysisPreviewOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'space-between',
    padding: 12,
  },
  
  analysisPreviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(139, 92, 246, 0.9)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  
  analysisPreviewHeaderText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  
  analysisPreviewContent: {
    marginTop: 'auto',
  },
  
  analysisPreviewTitle: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
  },
  
  analysisPreviewFeatures: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  
  featureBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  
  featureText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '500',
  },
  
  // Analysis Placeholder (if no preview image)
  analysisPlaceholder: {
    flex: 1,
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    borderRadius: 14,
  },
  
  analysisPlaceholderText: {
    color: '#8b5cf6',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 8,
    textAlign: 'center',
  },
  
  analysisPlaceholderSubtext: {
    color: '#94a3b8',
    fontSize: 12,
    marginTop: 4,
  },
  
  // Analysis Actions
  analysisActions: {
    flexDirection: 'row',
    backgroundColor: 'rgba(30, 41, 59, 0.8)',
    borderRadius: 12,
    padding: 8,
    marginTop: 8,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.2)',
  },
  
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 6,
  },
  
  actionButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  
  actionDivider: {
    width: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    marginHorizontal: 8,
  },
  
  // Message Text
  messageText: {
    fontSize: 15,
    lineHeight: 20,
    marginBottom: 6,
  },
  userMessageText: {
    color: '#fff',
  },
  assistantMessageText: {
    color: '#e5e7eb',
  },
  
  // Message Footer
  messageFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 4,
  },
  timestamp: {
    fontSize: 11,
  },
  userTimestamp: {
    color: 'rgba(255, 255, 255, 0.7)',
  },
  assistantTimestamp: {
    color: '#9ca3af',
  },
  statusIndicator: {
    marginLeft: 6,
  },
  
  // Typing Indicator
  typingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: '#1f2937',
    borderRadius: 20,
    alignSelf: 'flex-start',
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#374151',
  },
  typingDots: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  typingDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#8b5cf6',
  },
  typingDot1: {
    opacity: 0.4,
  },
  typingDot2: {
    opacity: 0.6,
  },
  typingDot3: {
    opacity: 0.8,
  },
  typingText: {
    color: '#9ca3af',
    marginLeft: 12,
    fontSize: 14,
    fontWeight: '500',
  },
});