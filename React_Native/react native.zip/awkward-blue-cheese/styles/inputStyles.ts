// styles/inputStyles.ts
import { StyleSheet, Platform } from 'react-native';

export const inputStyles = StyleSheet.create({
  // Input Container with reduced height
  inputContainer: {
    backgroundColor: '#1f2937',
    borderTopWidth: 1,
    borderTopColor: '#374151',
    paddingTop: 8,
    paddingBottom: Platform.OS === 'ios' ? 20 : 8,
    paddingHorizontal: 16,
  },
  
  // Selected Image Preview
  selectedImageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: 'rgba(139, 92, 246, 0.08)',
    marginBottom: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.15)',
  },
  selectedImageWrapper: {
    position: 'relative',
  },
  selectedImage: {
    width: 36,
    height: 36,
    borderRadius: 8,
    borderWidth: 1.5,
    borderColor: '#8b5cf6',
  },
  selectedImageBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#8b5cf6',
    width: 16,
    height: 16,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#1f2937',
  },
  selectedImageInfo: {
    flex: 1,
    marginLeft: 12,
  },
  selectedImageTitle: {
    color: '#f9fafb',
    fontSize: 14,
    fontWeight: '600',
  },
  selectedImageSubtitle: {
    color: '#9ca3af',
    fontSize: 12,
    marginTop: 2,
  },
  removeImageButton: {
    padding: 6,
    marginLeft: 4,
  },
  
  // Input Wrapper with reduced height
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#374151',
    borderRadius: 24,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: '#4b5563',
    minHeight: 44,
  },
  
  // Single Image Menu Button
  imageMenuButton: {
    padding: 8,
    marginRight: 4,
  },
  
  // Text Input with reduced height
  textInput: {
    flex: 1,
    color: '#f9fafb',
    fontSize: 15,
    paddingHorizontal: 8,
    paddingVertical: 6,
    minHeight: 32,
    maxHeight: 80,
    includeFontPadding: false,
    textAlignVertical: 'center',
  },
  
  // Send Button
  sendButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: '#8b5cf6',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 6,
    shadowColor: '#8b5cf6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  sendButtonDisabled: {
    backgroundColor: '#4b5563',
    shadowOpacity: 0,
  },
  
  // Android back button protector
  androidProtector: {
    height: 10,
    backgroundColor: 'transparent',
  },
});