import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Animated,
  StatusBar,
  Modal,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as MediaLibrary from 'expo-media-library';
import { 
  Ionicons, 
  MaterialIcons,
  FontAwesome5,
  Feather,
} from '@expo/vector-icons';
import WebView from 'react-native-webview';

// Import styles from separate files
import {
  width,
  height,
  isIOS,
  isAndroid,
  headerStyles,
  chatStyles,
  inputStyles,
} from './styles';
import { imageModalStyles } from './styles/imageModalStyles';

const API_URL = 'https://jubilant-fortnight-j9r7q59j7jvfg77-8000.app.github.dev';

type MessageType = {
  id: string;
  type: 'assistant' | 'user' | 'analysis';
  content: string;
  timestamp: Date;
  imageUri?: string;
  svgContent?: string;
  analysisImage?: string;
  status?: 'sending' | 'sent' | 'error';
};

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

export default function App() {
  const [text, setText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [messages, setMessages] = useState<MessageType[]>([
    {
      id: '1',
      type: 'assistant',
      content: 'Upload a business/finance problem image, and I\'ll create a detailed visual analysis with step-by-step explanations.',
      timestamp: new Date(),
    }
  ]);
  const [svgContent, setSvgContent] = useState<string>('');
  const [showSvgView, setShowSvgView] = useState(false);
  const [imageTitle, setImageTitle] = useState('');
  
  const scrollViewRef = useRef<ScrollView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [isCameraAvailable, setIsCameraAvailable] = useState(true);
  const webViewRef = useRef<WebView>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();

    // Check camera availability
    (async () => {
      const { status } = await ImagePicker.getCameraPermissionsAsync();
      setIsCameraAvailable(status === 'granted');
      
      // Check media library permission
      await MediaLibrary.requestPermissionsAsync();
    })();
  }, []);

  const scrollToBottom = () => {
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  // Show image source options (camera or gallery)
  const showImageOptions = () => {
    Alert.alert(
      'Select Image',
      'Choose image source',
      [
        {
          text: 'Camera',
          onPress: takePhoto,
          style: 'default',
        },
        {
          text: 'Gallery',
          onPress: selectImage,
          style: 'default',
        },
        {
          text: 'Cancel',
          style: 'cancel',
        },
      ]
    );
  };

  // Select image from gallery
  const selectImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(
          'Permission Required',
          'Please grant photo library access to select images.',
          [{ text: 'OK' }]
        );
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: false,
        quality: 0.85,
        allowsMultipleSelection: false,
      });

      if (!result.canceled && result.assets[0]) {
        setSelectedImage(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error selecting image:', error);
      Alert.alert('Error', 'Failed to select image. Please try again.');
    }
  };

  // Take photo with camera
  const takePhoto = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(
          'Camera Access Required',
          'Please grant camera permissions to take photos.',
          [{ text: 'OK' }]
        );
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: false,
        quality: 0.85,
      });

      if (!result.canceled && result.assets[0]) {
        setSelectedImage(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', 'Failed to take photo. Please try again.');
    }
  };

  // Generate analysis from image
  const generateAnalysis = async () => {
    if (!selectedImage) {
      Alert.alert('No Image', 'Please select an image first.');
      return;
    }

    setUploading(true);
    
    const messageId = Date.now().toString();
    
    // Add user message with image
    const userMessage: MessageType = {
      id: messageId,
      type: 'user',
      content: text.trim() || 'Analyze this image',
      timestamp: new Date(),
      imageUri: selectedImage,
      status: 'sending',
    };
    
    setMessages(prev => [...prev, userMessage]);
    setText('');
    scrollToBottom();
    
    try {
      // Create FormData
      const formData = new FormData();
      
      // Add text
      formData.append('text', text.trim() || '');
      
      // Add image
      const filename = selectedImage.split('/').pop() || `image_${Date.now()}.jpg`;
      
      // Get file type
      const fileExtension = filename.split('.').pop()?.toLowerCase() || 'jpg';
      let mimeType = 'image/jpeg';
      if (fileExtension === 'png') mimeType = 'image/png';
      if (fileExtension === 'gif') mimeType = 'image/gif';
      
      // Handle iOS file:// prefix
      let imageUri = selectedImage;
      if (Platform.OS === 'ios' && imageUri.startsWith('file://')) {
        imageUri = imageUri.replace('file://', '');
      }
      
      // Create the file object
      const file = {
        uri: imageUri,
        name: filename,
        type: mimeType,
      };
      
      console.log('Sending image for analysis...');
      
      // Append image
      formData.append('image', file as any);
      
      // Send request
      const response = await fetch(`${API_URL}/generate-svg`, {
        method: 'POST',
        body: formData,
        headers: {
          'Accept': 'application/json',
        },
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Analysis failed: ${response.status}`);
      }

      const result = await response.json();
      
      // Update user message status
      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? { ...msg, status: 'sent' } : msg
      ));
      
      // Get SVG content from response
      const svgText = result.svg;
      
      // Also get image preview for chat
      const imageBase64 = result.jpg || result.png;
      let previewImageUri = '';
      
      if (imageBase64) {
        previewImageUri = `data:image/jpeg;base64,${imageBase64}`;
      }
      
      // Add assistant message with analysis result
      const assistantMessage: MessageType = {
        id: (Date.now() + 1).toString(),
        type: 'analysis',
        content: '✅ Analysis Complete',
        timestamp: new Date(),
        svgContent: svgText,
        analysisImage: previewImageUri, // For preview in chat
        status: 'sent',
      };
      
      setMessages(prev => [...prev, assistantMessage]);
      setSelectedImage(null);
      scrollToBottom();
      
    } catch (error: any) {
      console.error('Error:', error);
      
      // Update message status
      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? { ...msg, status: 'error' } : msg
      ));
      
      // Add error message
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: '❌ Unable to analyze image. Please try again.',
        timestamp: new Date(),
        status: 'error',
      }]);
      
    } finally {
      setUploading(false);
    }
  };

  // Handle image loading errors
  const handleImageError = () => {
    // Silent fail for image errors
  };

  // Close SVG view
  const closeSvgView = () => {
    setShowSvgView(false);
  };

  // Get optimized SVG HTML template with SMOOTH animations
  const getSvgHtml = (svgContent: string) => {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes">
        <meta charset="UTF-8">
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
          }
          
          body {
            background: #000000;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            overflow: hidden;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            cursor: grab;
            position: relative;
          }
          
          body:active {
            cursor: grabbing;
          }
          
          .container {
            width: 100vw;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
          }
          
          svg {
            max-width: 100%;
            max-height: 100%;
            width: auto;
            height: auto;
            transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            transform-origin: center center;
            filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.1));
          }
          
          .zoom-indicator {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(0, 0, 0, 0.85);
            color: white;
            padding: 12px 18px;
            border-radius: 25px;
            font-size: 15px;
            font-weight: 600;
            z-index: 1000;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            min-width: 80px;
            justify-content: center;
          }
          
          .zoom-indicator.hidden {
            opacity: 0;
            transform: translateY(-10px);
          }
          
          .controls {
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 16px;
            z-index: 1000;
            padding: 12px 20px;
            background: rgba(0, 0, 0, 0.85);
            border-radius: 50px;
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
            transition: all 0.3s ease;
          }
          
          .controls.hidden {
            opacity: 0.5;
            transform: translateX(-50%) translateY(20px);
          }
          
          .control-btn {
            background: rgba(139, 92, 246, 0.95);
            color: white;
            border: none;
            width: 48px;
            height: 48px;
            border-radius: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            font-weight: 300;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(139, 92, 246, 0.3);
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            user-select: none;
            -webkit-user-select: none;
          }
          
          .control-btn:hover {
            background: rgba(139, 92, 246, 1);
            transform: scale(1.05);
          }
          
          .control-btn:active {
            transform: scale(0.95);
          }
          
          .control-btn.disabled {
            background: rgba(100, 100, 100, 0.5);
            cursor: not-allowed;
            transform: none !important;
            box-shadow: none;
          }
          
          .reset-btn {
            background: rgba(59, 130, 246, 0.95);
          }
          
          .reset-btn:hover {
            background: rgba(59, 130, 246, 1);
          }
          
          .instructions {
            position: fixed;
            bottom: 100px;
            left: 0;
            right: 0;
            text-align: center;
            color: rgba(255, 255, 255, 0.8);
            font-size: 14px;
            padding: 12px 24px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 20px;
            margin: 0 auto;
            width: fit-content;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
            z-index: 999;
          }
          
          .instructions.hidden {
            opacity: 0;
            transform: translateY(20px);
          }
          
          @media (max-width: 768px) {
            .controls {
              bottom: 40px;
              padding: 10px 16px;
              gap: 12px;
            }
            
            .control-btn {
              width: 44px;
              height: 44px;
              font-size: 22px;
            }
            
            .zoom-indicator {
              top: 30px;
              right: 16px;
              padding: 10px 16px;
              font-size: 14px;
            }
            
            .instructions {
              bottom: 120px;
              font-size: 13px;
              padding: 10px 20px;
            }
          }
          
          /* Smooth animations */
          .zoom-in {
            animation: zoomIn 0.3s ease-out;
          }
          
          .zoom-out {
            animation: zoomOut 0.3s ease-out;
          }
          
          @keyframes zoomIn {
            from { transform: scale(0.95); opacity: 0.8; }
            to { transform: scale(1); opacity: 1; }
          }
          
          @keyframes zoomOut {
            from { transform: scale(1.05); opacity: 0.8; }
            to { transform: scale(1); opacity: 1; }
          }
        </style>
      </head>
      <body>
        <div class="container" id="container">
          ${svgContent}
        </div>
        
        <div class="zoom-indicator" id="zoomIndicator">
          <span>🔍</span>
          <span id="zoomLevel">1.0x</span>
        </div>
        
        <div class="instructions" id="instructions">
          ✌️ Pinch to zoom • 👆 Drag to move • 👆 Double tap to reset
        </div>
        
        <div class="controls" id="controls">
          <button class="control-btn" id="zoomOutBtn" title="Zoom Out">−</button>
          <button class="control-btn reset-btn" id="resetBtn" title="Reset Zoom">↺</button>
          <button class="control-btn" id="zoomInBtn" title="Zoom In">+</button>
        </div>

        <script>
          // Smooth SVG Viewer with animations
          let scale = 1;
          let translateX = 0;
          let translateY = 0;
          let minScale = 0.5;
          let maxScale = 5;
          let isDragging = false;
          let startX, startY;
          let lastTouchDistance = null;
          let hideControlsTimeout;
          let controlsVisible = true;
          
          const svgElement = document.querySelector('svg');
          const container = document.getElementById('container');
          const zoomIndicator = document.getElementById('zoomIndicator');
          const zoomLevel = document.getElementById('zoomLevel');
          const instructions = document.getElementById('instructions');
          const controls = document.getElementById('controls');
          const zoomOutBtn = document.getElementById('zoomOutBtn');
          const resetBtn = document.getElementById('resetBtn');
          const zoomInBtn = document.getElementById('zoomInBtn');
          
          // Initialize SVG
          function initSvg() {
            if (!svgElement) return;
            
            // Set SVG attributes for smooth rendering
            svgElement.setAttribute('preserveAspectRatio', 'xMidYMid meet');
            svgElement.style.transformOrigin = 'center center';
            svgElement.style.cursor = 'grab';
            
            // Add smooth transition class
            svgElement.classList.add('zoom-in');
            
            // Update transform
            updateTransform();
            
            // Set up event listeners
            setupEventListeners();
            
            // Auto-hide controls after 3 seconds
            startAutoHide();
          }
          
          function setupEventListeners() {
            // Mouse events
            svgElement.addEventListener('mousedown', startDrag);
            document.addEventListener('mousemove', drag);
            document.addEventListener('mouseup', stopDrag);
            document.addEventListener('wheel', handleWheel, { passive: false });
            
            // Touch events
            svgElement.addEventListener('touchstart', startDragTouch, { passive: false });
            document.addEventListener('touchmove', dragTouch, { passive: false });
            document.addEventListener('touchend', stopDrag);
            
            // Double tap/click
            svgElement.addEventListener('dblclick', handleDoubleClick);
            let lastTap = 0;
            svgElement.addEventListener('touchend', function(e) {
              const currentTime = Date.now();
              if (currentTime - lastTap < 300) {
                e.preventDefault();
                handleDoubleClick();
              }
              lastTap = currentTime;
            });
            
            // Button events
            zoomOutBtn.addEventListener('click', smoothZoomOut);
            zoomInBtn.addEventListener('click', smoothZoomIn);
            resetBtn.addEventListener('click', smoothReset);
            
            // Show controls on interaction
            container.addEventListener('mousedown', showControls);
            container.addEventListener('touchstart', showControls);
          }
          
          function startDrag(e) {
            if (scale === 1) return;
            e.preventDefault();
            isDragging = true;
            startX = e.clientX - translateX;
            startY = e.clientY - translateY;
            svgElement.style.cursor = 'grabbing';
            showControls();
          }
          
          function startDragTouch(e) {
            if (scale === 1 || e.touches.length !== 1) return;
            e.preventDefault();
            isDragging = true;
            startX = e.touches[0].clientX - translateX;
            startY = e.touches[0].clientY - translateY;
            svgElement.style.cursor = 'grabbing';
            showControls();
          }
          
          function drag(e) {
            if (!isDragging) return;
            e.preventDefault();
            translateX = e.clientX - startX;
            translateY = e.clientY - startY;
            updateTransform();
          }
          
          function dragTouch(e) {
            if (!isDragging && e.touches.length !== 2) return;
            e.preventDefault();
            
            if (e.touches.length === 1 && isDragging) {
              translateX = e.touches[0].clientX - startX;
              translateY = e.touches[0].clientY - startY;
              updateTransform();
            } else if (e.touches.length === 2) {
              handlePinchZoom(e);
            }
          }
          
          function stopDrag() {
            isDragging = false;
            svgElement.style.cursor = 'grab';
          }
          
          function handleWheel(e) {
            e.preventDefault();
            const delta = e.deltaY > 0 ? -0.25 : 0.25;
            const oldScale = scale;
            scale = Math.max(minScale, Math.min(maxScale, scale + delta));
            
            // Smooth zoom towards cursor
            if (scale !== oldScale) {
              const rect = svgElement.getBoundingClientRect();
              const mouseX = e.clientX - rect.left;
              const mouseY = e.clientY - rect.top;
              
              const scaleChange = scale - oldScale;
              translateX -= (mouseX - rect.width / 2) * (scaleChange / oldScale);
              translateY -= (mouseY - rect.height / 2) * (scaleChange / oldScale);
              
              updateTransform();
              showControls();
              
              // Add animation class
              svgElement.classList.remove('zoom-in', 'zoom-out');
              svgElement.classList.add(delta > 0 ? 'zoom-in' : 'zoom-out');
              setTimeout(() => {
                svgElement.classList.remove('zoom-in', 'zoom-out');
              }, 300);
            }
          }
          
          function handlePinchZoom(e) {
            e.preventDefault();
            const touch1 = e.touches[0];
            const touch2 = e.touches[1];
            
            const currentDistance = Math.sqrt(
              Math.pow(touch2.clientX - touch1.clientX, 2) +
              Math.pow(touch2.clientY - touch1.clientY, 2)
            );
            
            if (lastTouchDistance !== null) {
              const scaleChange = (currentDistance - lastTouchDistance) * 0.01;
              const oldScale = scale;
              scale = Math.max(minScale, Math.min(maxScale, scale + scaleChange));
              
              if (scale !== oldScale) {
                const rect = svgElement.getBoundingClientRect();
                const centerX = (touch1.clientX + touch2.clientX) / 2 - rect.left;
                const centerY = (touch1.clientY + touch2.clientY) / 2 - rect.top;
                
                const scaleChange = scale - oldScale;
                translateX -= (centerX - rect.width / 2) * (scaleChange / oldScale);
                translateY -= (centerY - rect.height / 2) * (scaleChange / oldScale);
                
                updateTransform();
                showControls();
              }
            }
            
            lastTouchDistance = currentDistance;
          }
          
          function handleDoubleClick() {
            if (scale === 1) {
              smoothZoomIn();
            } else {
              smoothReset();
            }
          }
          
          function smoothZoomIn() {
            const oldScale = scale;
            scale = Math.min(maxScale, scale + 0.5);
            
            if (scale !== oldScale) {
              // Animate zoom
              svgElement.classList.remove('zoom-in', 'zoom-out');
              svgElement.classList.add('zoom-in');
              
              updateTransform();
              updateControls();
              showControls();
              
              setTimeout(() => {
                svgElement.classList.remove('zoom-in');
              }, 300);
            }
          }
          
          function smoothZoomOut() {
            const oldScale = scale;
            scale = Math.max(minScale, scale - 0.5);
            
            if (scale !== oldScale) {
              // Animate zoom
              svgElement.classList.remove('zoom-in', 'zoom-out');
              svgElement.classList.add('zoom-out');
              
              updateTransform();
              updateControls();
              showControls();
              
              setTimeout(() => {
                svgElement.classList.remove('zoom-out');
              }, 300);
            }
          }
          
          function smoothReset() {
            if (scale === 1) return;
            
            // Animate reset
            svgElement.classList.remove('zoom-in', 'zoom-out');
            svgElement.classList.add('zoom-out');
            
            scale = 1;
            translateX = 0;
            translateY = 0;
            
            updateTransform();
            updateControls();
            showControls();
            
            setTimeout(() => {
              svgElement.classList.remove('zoom-out');
            }, 300);
          }
          
          function updateTransform() {
            if (svgElement) {
              svgElement.style.transform = 'translate(' + translateX + 'px, ' + translateY + 'px) scale(' + scale + ')';
            }
            
            // Update zoom indicator
            if (zoomIndicator && zoomLevel) {
              zoomLevel.textContent = scale.toFixed(1) + 'x';
              if (scale === 1) {
                zoomIndicator.classList.add('hidden');
              } else {
                zoomIndicator.classList.remove('hidden');
              }
            }
            
            // Update instructions
            if (instructions) {
              if (scale === 1) {
                instructions.classList.remove('hidden');
              } else {
                instructions.classList.add('hidden');
              }
            }
          }
          
          function updateControls() {
            if (zoomOutBtn) {
              zoomOutBtn.classList.toggle('disabled', scale <= minScale);
            }
            if (zoomInBtn) {
              zoomInBtn.classList.toggle('disabled', scale >= maxScale);
            }
            if (resetBtn) {
              resetBtn.style.opacity = scale === 1 ? '0.5' : '1';
              resetBtn.style.cursor = scale === 1 ? 'default' : 'pointer';
            }
          }
          
          function showControls() {
            if (controlsVisible) return;
            
            clearTimeout(hideControlsTimeout);
            controlsVisible = true;
            
            if (controls) controls.classList.remove('hidden');
            if (zoomIndicator && scale !== 1) zoomIndicator.classList.remove('hidden');
            
            startAutoHide();
          }
          
          function hideControls() {
            if (scale !== 1) return; // Don't hide when zoomed
            
            controlsVisible = false;
            if (controls) controls.classList.add('hidden');
            if (zoomIndicator) zoomIndicator.classList.add('hidden');
          }
          
          function startAutoHide() {
            clearTimeout(hideControlsTimeout);
            hideControlsTimeout = setTimeout(hideControls, 3000);
          }
          
          // Initialize when page loads
          document.addEventListener('DOMContentLoaded', initSvg);
          
          // Reset touch distance on touch end
          document.addEventListener('touchend', function() {
            lastTouchDistance = null;
          });
          
          // Prevent context menu
          document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
          });
        </script>
      </body>
      </html>
    `;
  };

  // Render message
  const renderMessage = (message: MessageType) => {
    const isUser = message.type === 'user';
    const isAssistant = message.type === 'assistant';
    const isAnalysis = message.type === 'analysis';
    
    return (
      <Animated.View
        key={message.id}
        style={[
          chatStyles.messageRow,
          isUser ? chatStyles.userRow : chatStyles.assistantRow,
          { opacity: fadeAnim }
        ]}
      >
        {/* Avatar */}
        {!isUser && (
          <View style={chatStyles.assistantAvatar}>
            <FontAwesome5 name="robot" size={16} color="#8b5cf6" />
          </View>
        )}
        
        {/* Message Bubble */}
        <View style={[
          chatStyles.messageBubble,
          isUser ? chatStyles.userBubble : chatStyles.assistantBubble,
          isAnalysis && chatStyles.analysisBubble,
        ]}>
          {/* User uploaded image */}
          {isUser && message.imageUri && (
            <View style={chatStyles.userImageContainer}>
              <Image 
                source={{ uri: message.imageUri }} 
                style={chatStyles.userImage} 
                resizeMode="cover"
                onError={handleImageError}
              />
              <View style={chatStyles.imageBadge}>
                <Feather name="upload" size={12} color="#fff" />
                <Text style={chatStyles.imageBadgeText}>Uploaded</Text>
              </View>
            </View>
          )}
          
          {/* Analysis Result - Preview in Chat */}
          {isAnalysis && (
            <View style={chatStyles.analysisPreviewContainer}>
              {/* Preview Image with Overlay */}
              <TouchableOpacity
                style={chatStyles.analysisPreview}
                onPress={() => {
                  if (message.svgContent) {
                    setSvgContent(message.svgContent);
                    setImageTitle('AI Analysis Result');
                    setShowSvgView(true);
                  }
                }}
                activeOpacity={0.7}
              >
                {message.analysisImage ? (
                  <>
                    <Image
                      source={{ uri: message.analysisImage }}
                      style={chatStyles.analysisPreviewImage}
                      resizeMode="cover"
                      onError={handleImageError}
                    />
                    <View style={chatStyles.analysisPreviewOverlay}>
                      <View style={chatStyles.analysisPreviewHeader}>
                        <MaterialIcons name="analytics" size={18} color="#fff" />
                        <Text style={chatStyles.analysisPreviewHeaderText}>Analysis Ready</Text>
                      </View>
                      <View style={chatStyles.analysisPreviewContent}>
                        <Text style={chatStyles.analysisPreviewTitle}>
                          Tap to view interactive breakdown
                        </Text>
                        <View style={chatStyles.analysisPreviewFeatures}>
                          <View style={chatStyles.featureBadge}>
                            <Feather name="zoom-in" size={10} color="#8b5cf6" />
                            <Text style={chatStyles.featureText}>Zoomable</Text>
                          </View>
                          <View style={chatStyles.featureBadge}>
                            <Feather name="maximize-2" size={10} color="#8b5cf6" />
                            <Text style={chatStyles.featureText}>Interactive</Text>
                          </View>
                          <View style={chatStyles.featureBadge}>
                            <Feather name="bar-chart-2" size={10} color="#8b5cf6" />
                            <Text style={chatStyles.featureText}>Detailed</Text>
                          </View>
                        </View>
                      </View>
                    </View>
                  </>
                ) : (
                  <View style={chatStyles.analysisPlaceholder}>
                    <MaterialIcons name="analytics" size={32} color="#8b5cf6" />
                    <Text style={chatStyles.analysisPlaceholderText}>
                      Interactive Analysis Ready
                    </Text>
                    <Text style={chatStyles.analysisPlaceholderSubtext}>
                      Tap to view
                    </Text>
                  </View>
                )}
              </TouchableOpacity>
              
              {/* Quick Actions */}
              <View style={chatStyles.analysisActions}>
                <TouchableOpacity
                  style={chatStyles.actionButton}
                  onPress={() => {
                    if (message.svgContent) {
                      setSvgContent(message.svgContent);
                      setImageTitle('AI Analysis Result');
                      setShowSvgView(true);
                    }
                  }}
                >
                  <Feather name="maximize-2" size={14} color="#fff" />
                  <Text style={chatStyles.actionButtonText}>View Full</Text>
                </TouchableOpacity>
                
                <View style={chatStyles.actionDivider} />
                
                <TouchableOpacity
                  style={chatStyles.actionButton}
                  onPress={() => {
                    Alert.alert(
                      'Analysis Features',
                      '• AI Analysis\n• Step-by-step breakdown \n• Detailed calculations\n• Visual annotations',
                      [{ text: 'Got it' }]
                    );
                  }}
                >
                  <Feather name="info" size={14} color="#94a3b8" />
                  <Text style={[chatStyles.actionButtonText, { color: '#94a3b8' }]}>
                    Features
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          
          {/* Message text */}
          {message.content && (
            <Text style={[
              chatStyles.messageText,
              isUser ? chatStyles.userMessageText : chatStyles.assistantMessageText,
            ]}>
              {message.content}
            </Text>
          )}
          
          {/* Timestamp and Status */}
          <View style={chatStyles.messageFooter}>
            <Text style={[
              chatStyles.timestamp,
              isUser ? chatStyles.userTimestamp : chatStyles.assistantTimestamp
            ]}>
              {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </Text>
            
            {isUser && message.status === 'sending' && (
              <ActivityIndicator size={12} color="#94a3b8" style={chatStyles.statusIndicator} />
            )}
            {isUser && message.status === 'error' && (
              <Ionicons name="close-circle" size={14} color="#ef4444" />
            )}
            {isUser && message.status === 'sent' && (
              <Ionicons name="checkmark-circle" size={14} color="#10b981" />
            )}
          </View>
        </View>
        
        {/* User avatar */}
        {isUser && (
          <View style={chatStyles.userAvatar}>
            <Ionicons name="person" size={14} color="#fff" />
          </View>
        )}
      </Animated.View>
    );
  };

  return (
    <SafeAreaView style={chatStyles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#111827" />
      
      {/* Header with top padding */}
      <View style={headerStyles.header}>
        <View style={headerStyles.headerContent}>
          <View style={headerStyles.headerLeft}>
            <View style={headerStyles.logoContainer}>
              <View style={headerStyles.logoIcon}>
                <FontAwesome5 name="brain" size={20} color="#8b5cf6" />
              </View>
              <View>
                <Text style={headerStyles.headerTitle}>Business Analyzer</Text>
                <Text style={headerStyles.headerSubtitle}>AI-Powered Visual Analysis</Text>
              </View>
            </View>
          </View>
          <View style={headerStyles.headerRight}>
            <TouchableOpacity
              style={headerStyles.infoButton}
              onPress={() => {
                Alert.alert(
                  'How to Use',
                  '📱 **Business Analyzer**\n\n1. 📸 Tap + to select or take photo\n2. 💬 Add description (optional)\n3. 🚀 Tap send for AI analysis\n4. 👆 Tap analysis card to view\n\n**Interactive Features:**\n• Pinch to zoom in/out\n• Drag to move around\n• Double tap to reset\n• Smooth animations\n\n💡 **Tips:** Use clear images of financial statements, math problems, or charts.',
                  [{ text: 'Got it', style: 'default' }]
                );
              }}
            >
              <Feather name="help-circle" size={22} color="#94a3b8" />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* Chat Messages */}
      <ScrollView
        ref={scrollViewRef}
        style={chatStyles.chatContainer}
        contentContainerStyle={chatStyles.chatContent}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {messages.map(renderMessage)}
        
        {uploading && (
          <View style={chatStyles.typingIndicator}>
            <View style={chatStyles.typingDots}>
              <View style={[chatStyles.typingDot, chatStyles.typingDot1]} />
              <View style={[chatStyles.typingDot, chatStyles.typingDot2]} />
              <View style={[chatStyles.typingDot, chatStyles.typingDot3]} />
            </View>
            <Text style={chatStyles.typingText}>Analyzing with AI...</Text>
          </View>
        )}
      </ScrollView>

      {/* Input Area */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
        style={inputStyles.inputContainer}
      >
        {/* Selected Image Preview */}
        {selectedImage && (
          <View style={inputStyles.selectedImageContainer}>
            <View style={inputStyles.selectedImageWrapper}>
              <Image 
                source={{ uri: selectedImage }} 
                style={inputStyles.selectedImage} 
                onError={handleImageError}
              />
              <View style={inputStyles.selectedImageBadge}>
                <Feather name="image" size={12} color="#fff" />
              </View>
            </View>
            <View style={inputStyles.selectedImageInfo}>
              <Text style={inputStyles.selectedImageTitle}>Image ready</Text>
              <Text style={inputStyles.selectedImageSubtitle}>Tap send to analyze</Text>
            </View>
            <TouchableOpacity
              style={inputStyles.removeImageButton}
              onPress={() => setSelectedImage(null)}
            >
              <Ionicons name="close-circle" size={20} color="#ef4444" />
            </TouchableOpacity>
          </View>
        )}

        <View style={inputStyles.inputWrapper}>
          {/* Single Image Button */}
          <TouchableOpacity
            style={inputStyles.imageMenuButton}
            onPress={showImageOptions}
            disabled={uploading}
          >
            <Feather 
              name="plus" 
              size={22} 
              color={uploading ? "#6b7280" : "#8b5cf6"} 
            />
          </TouchableOpacity>

          {/* Text Input */}
          <TextInput
            style={inputStyles.textInput}
            placeholder="Message Business Analyzer..."
            placeholderTextColor="#94a3b8"
            value={text}
            onChangeText={setText}
            multiline
            maxLength={500}
            editable={!uploading}
            blurOnSubmit={false}
            textAlignVertical="center"
            returnKeyType="default"
            onSubmitEditing={() => {
              if (selectedImage && !uploading) {
                generateAnalysis();
              }
            }}
          />

          {/* Send Button */}
          <TouchableOpacity
            style={[
              inputStyles.sendButton,
              (!selectedImage || uploading) && inputStyles.sendButtonDisabled
            ]}
            onPress={generateAnalysis}
            disabled={!selectedImage || uploading}
          >
            {uploading ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Ionicons name="send" size={18} color="#fff" />
            )}
          </TouchableOpacity>
        </View>
        
        {/* Android back button protection */}
        {Platform.OS === 'android' && (
          <View style={inputStyles.androidProtector} />
        )}
      </KeyboardAvoidingView>

      {/* Interactive SVG Modal */}
      <Modal
        visible={showSvgView}
        transparent={false}
        animationType="slide"
        onRequestClose={closeSvgView}
        statusBarTranslucent={true}
      >
        <SafeAreaView style={imageModalStyles.fullImageModal}>
          {/* Header */}
          <View style={imageModalStyles.fullImageHeader}>
            <TouchableOpacity
              onPress={closeSvgView}
              style={imageModalStyles.closeFullImageButton}
              hitSlop={{ top: 15, bottom: 15, left: 15, right: 15 }}
            >
              <Ionicons name="arrow-back" size={24} color="#fff" />
            </TouchableOpacity>
            <Text style={imageModalStyles.fullImageTitle} numberOfLines={1}>
              {imageTitle}
            </Text>
            <View style={imageModalStyles.fullImageHeaderSpacer} />
          </View>
          
          {/* WebView for Interactive SVG */}
          <WebView
            ref={webViewRef}
            source={{ html: getSvgHtml(svgContent) }}
            style={{ flex: 1, backgroundColor: '#000' }}
            javaScriptEnabled={true}
            domStorageEnabled={true}
            scalesPageToFit={true}
            startInLoadingState={true}
            allowsFullscreenVideo={false}
            mediaPlaybackRequiresUserAction={false}
            renderLoading={() => (
              <View style={imageModalStyles.noFullImageContainer}>
                <View style={imageModalStyles.loadingAnimation}>
                  <ActivityIndicator size="large" color="#8b5cf6" />
                  <Text style={imageModalStyles.loadingText}>Loading interactive analysis...</Text>
                  <Text style={imageModalStyles.loadingSubtext}>This may take a moment</Text>
                </View>
              </View>
            )}
            onError={(error) => {
              console.error('WebView error:', error);
              Alert.alert('Error', 'Failed to load interactive view. Please try again.');
            }}
            onLoadEnd={() => {
              // Smooth fade in
              if (webViewRef.current) {
                // WebView loaded successfully
              }
            }}
          />
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}